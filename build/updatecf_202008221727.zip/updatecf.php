<?php
declare(strict_types=1);
/**
 * Woluweb - Update Custom Field project
 * A plugin allowing to populate Joomla Custom Fields from Webservices
 * php version 7.2
 *
 * @package   Updatecf
 * @author    Pascal Leconte <pascal.leconte@conseilgouz.com>
 * @author    Christophe Avonture <christophe@avonture.be>
 * @author    Marc Dechèvre <marc@woluweb.be>
 * @author    Alexandre ELISÉ <contact@alexandre-elise.fr>
 * @license   GNU GPL-2.0-or-later
 *
 * @link      https://github.com/woluweb/updatecf
 * @wiki https://github.com/woluweb/updatecf/-/wikis/home
 */

// phpcs:disable PSR1.Files.SideEffects

defined('_JEXEC') or die('Restricted access');

use AE\Library\CustomField\Service\Core;
use Joomla\CMS\Factory;
use Joomla\CMS\Filesystem\File;
use Joomla\CMS\Filesystem\Folder;
use Joomla\CMS\Plugin\CMSPlugin;


/**
 * The Update Custom Fields system plugin.
 *
 * @SuppressWarnings(PHPMD.CyclomaticComplexity)
 * @SuppressWarnings(PHPMD.NPathComplexity)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 */
class PlgSystemUpdatecf extends CMSPlugin
{
	/**
	 * PlgSystemUpdatecf constructor.
	 *
	 * @param          $subject
	 * @param   array  $config
	 */
	public function __construct(&$subject, $config = [])
	{
		// 4.0. compatibility
		jimport('joomla.filesystem.folder');
		jimport('joomla.filesystem.file');
		
		parent::__construct($subject, $config);
		
		JLoader::registerNamespace(
			'AE\\Library\\CustomField\\',
			JPATH_PLUGINS
			. DIRECTORY_SEPARATOR
			. 'system'
			. DIRECTORY_SEPARATOR
			. 'updatecf'
			. DIRECTORY_SEPARATOR
			. 'libraries'
			. DIRECTORY_SEPARATOR
			. 'AE'
			. DIRECTORY_SEPARATOR
			. 'Library'
			. DIRECTORY_SEPARATOR
			. 'CustomField'
			, false
			, false
			, 'psr4'
		);
		// can be used by a real cronjob scheduler
		$cliScriptFileName = File::makeSafe(
			JPATH_ROOT
			. DIRECTORY_SEPARATOR
			. 'cli'
			. DIRECTORY_SEPARATOR
			. 'updatecf-cli.php');
		
		// destination folder
		$cliScriptFolder = Folder::makeSafe(
			JPATH_ROOT
			. DIRECTORY_SEPARATOR
			. 'cli'
		);
		
		// copy joomla cli application script from this plugin cli folder
		// to the real joomla default cli folder
		if (!file_exists($cliScriptFileName))
		{
			File::copy(
				$cliScriptFileName,
				$cliScriptFolder
			);
		}
	}
	
	/**
	 * Joomla! onAfterRoute
	 *
	 * @return void
	 */
	public function onAfterRoute(): void
	{
		$input = Factory::getApplication()->input;
		
		// Get an empty string when the plugin wasn't called from the Edit plugin backend page
		$pJform = $input->get('jform', '', 'array');
		
		if ('' != $pJform)
		{
			// Plugin called from the Edit plugin page, run the "manual" synchronization
			if ('updatecf' === $pJform['element'])
			{
				Core::manualPluginSaving($pJform);
			}
		}
	}
	
}
