<?php
declare(strict_types=1);
/**
 * @package       Core
 * @author        Alexandre ELISÉ <contact@alexandre-elise.fr>
 * @link          https://alexandre-elise.fr
 * @copyright (c) 2020 . Alexandre ELISÉ . Tous droits réservés.
 * @license       GPL-2.0-and-later GNU General Public License v2.0 or later
 * Created Date : 21/08/2020
 * Created Time : 20:46
 */

namespace AE\Library\CustomField\Service;

use AE\Library\CustomField\Core\Constant;
use AE\Library\CustomField\Helper\Content;
use JLoader;
use Joomla\CMS\Log\Log;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\CMS\Version;
use Joomla\Registry\Registry;
use function substr;
use const DIRECTORY_SEPARATOR;

defined('_JEXEC') or die;

/**
 * @package     AE\Library\CustomField\Service
 *
 * @since       version
 */
abstract class Core
{
	/**
	 * Make the update, process articles.
	 *
	 * @param   \Joomla\Registry\Registry  $plugin_params
	 *
	 * @return void
	 * @author    Marc Dechèvre <marc@woluweb.be>
	 * @author    Pascal Leconte <pascal.leconte@conseilgouz.com>
	 * @author    Christophe Avonture <christophe@avonture.be>
	 * @author    Alexandre ELISÉ <contact@alexandre-elise.fr>
	 */
	public static function goUpdate(Registry $plugin_params): void
	{
		$categories = $plugin_params->get('categories');
		
		if (null === $categories) {
			$res        = Content::getAllCategories();
			$categories = [];
			foreach ($res as $catid) {
				if ($catid->count > 0) {
					$categories[] = $catid->id;
				}
			}
		}
		
		$joomlaVersion = new Version();
		$majorVersion  = (int) substr($joomlaVersion->getShortVersion(), 0, 1);
		
		if ($majorVersion >= Constant::JOOMLA_4) {
			$articles     = new ArticlesModel(['ignore_request' => true]);
		} else {
			JLoader::register('ContentModelArticles',
				JPATH_SITE
				. DIRECTORY_SEPARATOR
				.'components'
				. DIRECTORY_SEPARATOR
				. 'com_content'
				. DIRECTORY_SEPARATOR
				. 'models'
				. DIRECTORY_SEPARATOR
				. 'articles.php'
			);
			$articles = BaseDatabaseModel::getInstance('Articles', 'ContentModel', ['ignore_request' => true]);
		}
		
		if ($articles) {
			$params = new Registry();
			
			$articles->setState('params', $params);
			$articles->setState('list.limit', 0);
			$articles->setState('list.start', 0);
			$articles->setState('filter.tag', 0);
			$articles->setState('list.ordering', 'a.ordering');
			$articles->setState('list.direction', 'ASC');
			$articles->setState('filter.published', 1);
			
			$articles->setState('filter.category_id', $categories);
			
			$articles->setState('filter.featured', 'show');
			$articles->setState('filter.author_id', '');
			$articles->setState('filter.author_id.include', 1);
			$articles->setState('filter.access', false);
			
			$items = $articles->getItems();
			
			// Process all articles
			foreach ($items as $item) {
				Content::updateArticleCustomFields($item, $plugin_params);
			}
		}
	}
	
	/**
	 * The present plugin will trigger automatically at the frequency configured
	 * in the Plugin Options.
	 *
	 * To do so it creates a file with the timestamp of the last execution
	 * Note: the manual way to trigger the Plugin is simply to (Open and) Save it
	 *
	 * @param array $config Configuration items of the plugin
	 *
	 * @return void
	 */
	public static function manualPluginSaving(array $config): void
	{
		if (!(isset($config['params']['freq']))) {
			return;
		}
		
		// save request params to registry
		$plugin_params = new Registry($config['params']);
		
		static::goUpdate($plugin_params);
		
		Log::add('OK', Log::INFO, 'Plugin has been edited and saved');
	}
}
